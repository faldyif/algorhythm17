<?php 
	header("location:./public/") ;
?>