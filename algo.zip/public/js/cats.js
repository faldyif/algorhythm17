var cats = ['Koko', 'Kiki', 'Keke', 'Kuka'] ;

export default cats ;