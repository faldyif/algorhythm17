import cats from './cats.js' ;

	console.log('Ini diload dari bundle') ;
	for(const cat of cats){
		console.log(cat) ;
	}