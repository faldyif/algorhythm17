<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Dashboard - Algorhythm</title>
<meta name="description" content="">
<meta name="keywords" content="Algo rhythm, Algorhythm UGM, UGM, himakomsi, event">

<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<!-- Scripts -->
<script>
  window.Laravel = <?php echo json_encode([
    'csrfToken' => csrf_token(),
    ]); ?>
  </script>


  <!-- Shortcut icon -->
  <link rel="shortcut icon" type="x-icon" href="../img/icon.png">
  
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:400,300|Raleway:300,400,900,700italic,700,300,600">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/jquery.bxslider.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/font-awesome.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/animate.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/baker-theme.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/algorhythm-style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('css/sweetalert.css')); ?>">

  <!-- =======================================================
      Theme Name: Baker
      Theme URL: https://bootstrapmade.com/baker-free-onepage-bootstrap-theme/
      Author: BootstrapMade.com
      Author URL: https://bootstrapmade.com
      ======================================================= -->
    </head>
    <body class="flatWhiteSec">
      <!--  -->
      <nav class="navbar navbar-fixed-top navbar-fixed-custom">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="#">
              <img src="<?php echo e(url('img/text.png')); ?>">
            </a>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#asideNav">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>                        
            </button>
          </div>
          <ul class="nav navbar-nav navbar-right wh">
            <li class="username">Hello, <span class="bold"><?php echo e(Auth::user()->name); ?></span></li>
            <li><a href="<?php echo e(url('/logout')); ?>" class="btn btn-purple-1" onclick="event.preventDefault();
              document.getElementById('logout-form').submit();"><span class="fa fa-sign-out"></span> Sign Out</a></li>
            </ul>
            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
              <?php echo e(csrf_field()); ?>

            </form>
          </div>
        </nav>
        <!--  -->
        <!-- aside -->


        <?php echo $__env->yieldContent('content'); ?>

      </section>
      <!-- /aside -->
      <script src="<?php echo e(url('js/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(url('js/jquery.easing.min.js')); ?>"></script>
      <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
      <script src="<?php echo e(url('js/wow.js')); ?>"></script>
      <script src="<?php echo e(url('js/jquery.bxslider.min.js')); ?>"></script>
      <script src="<?php echo e(url('js/custom.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(url('js/modernizr.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(url('js/jquery.nicescroll.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(url('js/lightcase.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(url('js/wow.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(url('js/owl.carousel.min.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(url('js/jquery.js')); ?>"></script>
      <script type="text/javascript" src="<?php echo e(url('js/sweetalert.min.js')); ?>"></script>
      <script type="text/javascript">
        $(document).ready(function(){
        // wow js
        new WOW().init() ;
        }) ;
      </script>
</body>
</html>