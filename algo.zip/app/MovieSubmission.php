<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MovieSubmission extends Model
{
    //
}
