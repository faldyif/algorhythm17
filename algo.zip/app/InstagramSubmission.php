<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InstagramSubmission extends Model
{
    //
}
